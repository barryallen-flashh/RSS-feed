# Cybercrime RSS Feed

Automatically updated RSS feed from [Cybersecurity Ventures](https://cybersecurityventures.com/cybercrime-news/), refreshed hourly.

## RSS Feed URL

Once deployed, access:  
`https://<your-username>.github.io/cybercrime-rss/cybercrime_news.xml`
